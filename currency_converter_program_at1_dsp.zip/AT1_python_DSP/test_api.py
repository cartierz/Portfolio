import unittest
from api import call_api, format_currencies_url, get_currencies, format_latest_url, _HOST_, _LATEST_, _CURRENCIES_


class TestFormatUrl(unittest.TestCase):
    def setUp(self):
        self.format_currencies_url = "https://api.frankfurter.app/currencies"
        self.format_latest_url =  _HOST_ + _LATEST_ + "?from=" + "GBP" + "&to=" + "AUD"
        
    def test_function_currencies(self):
        currency_url = _HOST_ + _CURRENCIES_
        self.assertEqual(currency_url, self.format_currencies_url)

    def test_function_latest(self):
        latest_url = _HOST_ + _LATEST_ + "?from=" + "GBP" + "&to=" + "AUD"
        self.assertEqual(latest_url, self.format_latest_url)
    
    def test_function_currencies_str(self):
        currency_url = "test"
        self.assertNotEqual(currency_url, self.format_currencies_url)

    def test_function_latest_str(self):
        latest_url = "test"
        self.assertNotEqual(latest_url, self.format_latest_url)

    def test_function_currencies_empty(self):
        currency_url = " "
        self.assertNotEqual(currency_url, self.format_currencies_url)

    def test_function_latest_empty(self):
        latest_url = " "
        self.assertNotEqual(latest_url, self.format_latest_url)

    def test_function_currencies_none(self):
        currency_url = None
        self.assertNotEqual(currency_url, self.format_currencies_url)

    def test_function_latest_none(self):
        latest_url = None
        self.assertNotEqual(latest_url, self.format_latest_url)
        
class TestAPI(unittest.TestCase):
    def setUp(self):
        self.statuscode = 200

    def test_function_str(self):
        with self.assertRaises(Exception):
            call_api("test")
    
    def test_function_latest(self):
        resp = call_api(_HOST_ + _LATEST_ + "?from=" + "GBP" + "&to=" + "AUD")
        latest_status = resp.status_code
        self.assertEqual(latest_status, self.statuscode)
    
    def test_function_currencies(self):
        resp = call_api(_HOST_ + _CURRENCIES_)
        currencies_status= resp.status_code
        self.assertEqual(currencies_status, self.statuscode)
    
    def test_function_empty(self):
        with self.assertRaises(Exception):
            call_api(" ")

    def test_function_none(self):
        with self.assertRaises(Exception):
            call_api("None")

if __name__ == '__main__':
    unittest.main()