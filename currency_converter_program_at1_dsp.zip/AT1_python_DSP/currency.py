from dataclasses import dataclass
from api import get_currencies
import sys

CURRENCIES = get_currencies()

def check_valid_currency(currency: str) -> bool:
    """
    Function that will check currency code is amongst the list of available currencies

    Parameters
    ----------
    currency : str
    Currency code to be checked

    Pseudo-code
    ----------
    if currency is not None
        and if the currency parameter as upper case is in CURRENCIES list
            return bool True
        or else 
            return bool False
    or else 
        return False

    Returns
    -------
    bool
    True if the currency code is valid otherwise False
    """
    if currency is not None:
        if currency.upper() in CURRENCIES:
            return True
        else:
            return False
    else:
        return False

@dataclass
class Currency:
    """
    Class that represents a Currency conversion object. 

    Attributes
    ----------
    from_currency : str
        Code for the origin currency
    to_currency : str
        Code for the destination currency
    amount : float
        The amount (in origin currency) to be converted
    rate : float
        The conversion rate to be applied on the origin amount (origin -> destination)
    inverse_rate : float
        The inverse of the previous rate  (destination -> origin)
    date : str
        Date when the conversion rate was recorded
    """
    from_currency: str = None
    to_currency: str = None
    amount: float = 0
    rate: float = 0
    inverse_rate: float = 0
    date: str = None
    def reverse_rate(self):
        """
        Method that will calculate the inverse rate, round it to 5 decimal places and save it in the attribute inverse_rate

        Parameters
        ----------
        None

        Returns
        -------
        None
        """
        return round(1/self.rate, 5)
    def format_result(self):
        """
        Methods returning the formatted successful message

        Parameters
        ----------
        None

        Returns
        -------
        str
            Formatted successful message
        """
    
        return f"Today's {self.date} conversion rate from {sys.argv[1]} to {sys.argv[2]} is {self.amount*self.rate}. The inverse rate is {self.amount*self.inverse_rate}"

def extract_api_result(result: dict) -> Currency:
    """
    Function that will extract the relevant fields from API result, instantiate a Currency class accordingly and
    calculate the inverse rate

    Parameters
    ----------
    result : dict
        Results of the API converted as dictionary

    Pseudo-code
    ----------
    if result parameter is not None 
        instantiate currency class as currency_object
        extract value from base key of result as from_currency of currency_object class
        extract the values from rates key in result dictionary as rates
        extract rates key from rates as second_currency 
        extract currency code from second_currency as a string to assign to to_currency of currency_object
        extract value from amount key of result as amount of currency_object class
        for dictionary in rates that contains both k key and v value
                float v for rate in currency_object
        assign reverse_rate of Currency as inverse_rate of currency_object class
        extract value date key from results as date of currency_object class
        display success message from Currency
        return currency_object
    
    Returns
    -------
    Currency
        Instantiated Currency
    """ 
    if result is not None:
        currency_object = Currency()
        currency_object.from_currency = result.get("base")
        rates = result.get("rates")
        second_currency = rates.keys()
        currency_object.to_currency = str(second_currency)[12:15]
        currency_object.amount = result.get("amount")
        for k, v in rates.items():
            currency_object.rate = float(v)
        currency_object.inverse_rate = currency_object.reverse_rate()
        currency_object.date = result.get("date")
        print(currency_object.format_result())
        return currency_object