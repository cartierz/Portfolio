<h1 align="center">DSP Currency Converter Program></h1>

## Author

**Cartier Zhi**

- Student ID: 14171767
- Email: cartier.zhi@student.uts.edu.au

## Description
The app is built for returning currency conversion rate between two currencies and its inverse rate from currency codes that are available from the Frankfurter API.

## Available Commands

In the project directory, you can run:

### `python3 main.py AUD EUR`,

If you are using Pipenv, then you can run:

### `pipenv run python3 main.py AUD EUR`,

## Built With

- Python

## Package Dependencies

- requests
- datetime

## Structure

    ├── api.py             <- Calling the specified API endpoints
    ├── currency.py        <- Check input validity, store results & format final outputs
    ├── main.py            <- Main script for currency code inputs & displaying results
    ├── Pipfile            <- Required language version, packages and package source
    ├── Pipfile.lock       <- Details of the environment with package and version details
    ├── README.md          <- Details about files in directory, with student's details
    ├── test_api.py        <- Testing code from api.py
    └── test_currency.py   <- Testing code from currency.py
